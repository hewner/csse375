package net.sf.jftp.event;

public interface FtpEventConstants
{
    public final static int FTPCommand = 100;
    public final static int FTPPrompt = 200;
    public final static int FTPShutdown = 900;
}
